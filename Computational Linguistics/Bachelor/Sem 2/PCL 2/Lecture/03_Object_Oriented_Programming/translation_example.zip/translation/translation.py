import re
from abc import ABC, abstractmethod
from typing import Iterator, Sequence

import googletrans
import sacrebleu


class ParallelDataset:
    def __init__(self, source: Sequence[str], target: Sequence[str]):
        self._source = source
        self._target = target

    @classmethod
    def load(cls, source_filename: str, target_filename: str) -> "ParallelDataset":
        with open(source_filename) as f:
            source = [line.strip() for line in f]
        with open(target_filename) as f:
            target = [line.strip() for line in f]
        return cls(source, target)

    def __len__(self) -> int:
        return len(self._source)

    def __getitem__(self, i) -> tuple[str, str]:
        return self._source[i], self._target[i]

    def __iter__(self) -> Iterator[tuple[str, str]]:
        for i in range(len(self)):
            yield self[i]


class Translator(ABC):
    requires_network = False

    def __init__(self, source_lang: str, target_lang: str):
        self.source_lang = source_lang
        self.target_lang = target_lang

    @abstractmethod
    def translate(self, text: str) -> str:
        pass

    def evaluate(self, dataset: ParallelDataset) -> float:
        translations = [self.translate(source) for source, _ in dataset]
        targets = [target for _, target in dataset]
        return sacrebleu.corpus_bleu(translations, [targets]).score


class WordByWordTranslator(Translator):
    def __init__(self, dictionary: dict[str, str], **kwargs):
        super().__init__(**kwargs)
        self._dictionary = dictionary

    @classmethod
    def load(cls, filename: str) -> "WordByWordTranslator":
        source_lang, target_lang = re.search(r"([a-z]+)-([a-z]+).tsv", filename).groups()
        with open(filename) as f:
            dictionary = dict(line.strip().split("\t") for line in f)
        return cls(dictionary, source_lang=source_lang, target_lang=target_lang)

    def translate(self, text: str) -> str:
        tokens = text.split()
        translation = " ".join(self._dictionary.get(token, token) for token in tokens)
        return translation


class GoogleTranslator(Translator):
    requires_network = True

    def __init__(self, source_lang: str, target_lang: str):
        super().__init__(source_lang, target_lang)
        self._translator = googletrans.Translator()

    def translate(self, text: str) -> str:
        translation = self._translator.translate(
            text, src=self.source_lang, dest=self.target_lang
        )
        return translation.text


if __name__ == "__main__":
    dataset = ParallelDataset.load("test.src", "test.trg")
    translators = [
        WordByWordTranslator.load("en-de.tsv"),
        GoogleTranslator("en", "de"),
    ]
    for translator in translators:
        print(f"{translator.__class__.__name__}: BLEU={translator.evaluate(dataset)}")
