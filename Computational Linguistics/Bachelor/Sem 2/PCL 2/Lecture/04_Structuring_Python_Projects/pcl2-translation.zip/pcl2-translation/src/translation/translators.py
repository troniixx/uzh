from abc import ABC, abstractmethod
import sacrebleu
import googletrans

from translation.data import ParallelDataset


class Translator(ABC):
    requires_network = False

    @abstractmethod
    def translate(self, text: str) -> str:
        pass

    def evaluate(self, dataset: ParallelDataset) -> float:
        translations = [self.translate(source) for source, _ in dataset]
        targets = [target for _, target in dataset]
        return sacrebleu.corpus_bleu(translations, [targets]).score


class WordByWordTranslator(Translator):
    def __init__(self, dictionary: dict[str, str]):
        self._dictionary = dictionary

    def translate(self, text: str) -> str:
        tokens = text.split()
        translation = " ".join(self._dictionary.get(token, token) for token in tokens)
        return translation

    @classmethod
    def load(cls, filename: str) -> "WordByWordTranslator":
        with open(filename) as f:
            dictionary = dict(line.strip().split("\t") for line in f)
        return cls(dictionary)


class GoogleTranslator(Translator):
    requires_network = True

    def __init__(self, source_lang: str, target_lang: str):
        self._translator = googletrans.Translator()
        self._source_lang = source_lang
        self._target_lang = target_lang

    def translate(self, text: str) -> str:
        translation = self._translator.translate(text, src=self._source_lang, dest=self._target_lang)
        return translation.text
