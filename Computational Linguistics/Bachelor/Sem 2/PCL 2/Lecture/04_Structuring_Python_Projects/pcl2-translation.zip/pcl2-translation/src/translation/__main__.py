import sys

from translation import WordByWordTranslator

translator = WordByWordTranslator.load(sys.argv[1])

print("> ", end="", flush=True)
for line in sys.stdin:
    print(translator.translate(line))
    print("\n> ", end="", flush=True)
