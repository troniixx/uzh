from typing import Iterator, Sequence


class ParallelDataset:
    def __init__(self, source: Sequence[str], target: Sequence[str]):
        self._source = source
        self._target = target

    @classmethod
    def load(cls, source_filename: str, target_filename: str) -> "ParallelDataset":
        with open(source_filename) as f:
            source = [line.strip() for line in f]
        with open(target_filename) as f:
            target = [line.strip() for line in f]
        return cls(source, target)

    def __len__(self) -> int:
        return len(self._source)

    def __getitem__(self, i) -> tuple[str, str]:
        return self._source[i], self._target[i]

    def __iter__(self) -> Iterator[tuple[str, str]]:
        for i in range(len(self)):
            yield self[i]
