import sys


def main():
    # first positional argument is the input file
    input = sys.argv[1]
    # second positional argument is the number of lines to process
    num_lines = int(sys.argv[2])
    # third argument (optional) is the output file
    if len(sys.argv) == 4:
        output = open(sys.argv[3], "w")
    else:
        # if no output file is specified, write to stdout
        output = sys.stdout

    # iterate over the lines in the input file
    for i, line in enumerate(open(input)):
        # stop processing if we have processed the number of lines specified
        if i == num_lines:
            break
        # uppercase the line and write it to the output file
        output.write(line.upper())

    output.close()


if __name__ == "__main__":
    main()